# ============================================================================
# JarvisFA - R8/ProGuard rules
# Goal (item 3): maximize obfuscation & make reverse engineering as hard as
# possible while keeping JNI, Kotlin metadata and Jetpack Compose working.
# ============================================================================

# ---------------- Aggressive obfuscation ----------------
# Repackage ALL classes into a single root package 'a'.
-repackageclasses 'a'

# Same short identifier reused for as many members as possible.
-overloadaggressively

# Merge interfaces aggressively.
-mergeinterfacesaggressively

# Obfuscation dictionaries (unicode identifiers -> unreadable stack traces).
-classobfuscationdictionary proguard/dictionary.txt
-obfuscationdictionary proguard/dictionary.txt
-packageobfuscationdictionary proguard/dictionary.txt

# Strip source-file names from release builds.
-renamesourcefileattribute SourceFile

# ---------------- JNI (critical) ----------------
# NativeBridge is called from C++ by name; renaming breaks the license layer.
-keep class com.jarvisfa.security.NativeBridge { *; }
# Generic safety net: never rename any class that declares native methods.
-keepclasseswithmembers class * {
    native <methods>;
}
# Keep the JNI glue of the NDK log library.
-keepclasseswithmembernames class * {
    native <methods>;
}

# ---------------- Kotlin ----------------
-keepclassmembers class **$Companion { *; }
-keepclassmembers class ** {
    @org.jetbrains.annotations.NotNull public *;
    @org.jetbrains.annotations.Nullable public *;
}
-dontwarn kotlin.**

# ---------------- Jetpack Compose (consumer rules ship with the libs) ----------------
-dontwarn androidx.compose.**
-keep class androidx.compose.** { *; }

# ---------------- sherpa-onnx (offline voice core, item 5/16/27) ----------------
-keep class com.k2fsa.sherpa.onnx.** { *; }
-dontwarn com.k2fsa.sherpa.onnx.**

# ---------------- Encrypted media / ONNX model loading via reflection-free APIs ----------------
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
-keep @interface androidx.annotation.Keep

# ---------------- Remove logging in release ----------------
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
