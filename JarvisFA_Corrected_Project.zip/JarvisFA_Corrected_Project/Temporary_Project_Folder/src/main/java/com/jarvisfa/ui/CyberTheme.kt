package com.jarvisfa.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// تعریف پلت رنگی نئونی و سایبربانکی انحصاری پروژه JarvisFA
private val CyberColorScheme = darkColorScheme(
    primary = Color(0xFF00FFCC),       // سبز نئونی اصلی
    secondary = Color(0xFF0066FF),     // آبی سایبر
    tertiary = Color(0xFF9900FF),      // بنفش کریپتو
    background = Color(0xFF0A0F1D),    // مشکی تیره شاسی
    surface = Color(0xFF1F2942),       // خاکستری دکمه‌ها
    error = Color(0xFFFF0055)          // قرمز هشدار لایسنس
)

@Composable
fun CyberTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CyberColorScheme,
        content = content
    )
}
