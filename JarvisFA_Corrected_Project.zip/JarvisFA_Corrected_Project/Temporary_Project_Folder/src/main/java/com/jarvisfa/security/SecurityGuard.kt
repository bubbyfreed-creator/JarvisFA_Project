package com.jarvisfa.security

import android.app.ActivityManager
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.util.Log

class SecurityGuard(private val context: Context) {
    private var isBankProtectionActive = false
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    init {
        activateBankBodyguard()
        checkDeviceIntegrity()
    }

    fun activateBankBodyguard() {
        isBankProtectionActive = true
        AuditLogger.logEvent("Bank Bodyguard subsystems successfully initialized.")
    }

    // ۱. بررسی بومی وضعیت روت بودن دستگاه در هسته بادیگارد بانکی
    private fun checkDeviceIntegrity() {
        val isRooted = NativeBridge.isDeviceRooted()
        if (isRooted) {
            AuditLogger.logEvent("SECURITY WARNING: Root environment detected via JNI!")
            // تشدید تدابیر امنیتی در صورت روت بودن سیستم
            enforceClipboardProtection()
        } else {
            AuditLogger.logEvent("Device integrity check: Clean env verified.")
        }
    }

    fun monitorRunningTasks(): String? {
        if (!isBankProtectionActive) return null
        
        try {
            val runningAppProcesses = activityManager.runningAppProcesses ?: return null
            for (processInfo in runningAppProcesses) {
                val pkgName = processInfo.processName.toLowerCase()
                
                if (pkgName.contains("bank") || pkgName.contains("payment") || pkgName.contains("crypto") || pkgName.contains("wallet")) {
                    AuditLogger.logEvent("SECURITY ALERT: Financial app target isolated -> $pkgName")
                    enforceClipboardProtection()
                    return processInfo.processName
                }
            }
        } catch (e: Exception) {
            Log.e("JarvisFA_Guard", "Failed to scan running tasks: ${e.message}")
        }
        return null
    }

    private fun enforceClipboardProtection() {
        try {
            val clipData = ClipData.newPlainText("secured", "")
            clipboardManager.setPrimaryClip(clipData)
            AuditLogger.logEvent("SecurityGuard: Clipboard memory cleared and isolated.")
        } catch (e: Exception) {
            Log.e("JarvisFA_Guard", "Clipboard isolation error: ${e.message}")
        }
    }

    fun triggerEmergencyLockdown() {
        AuditLogger.logEvent("CRITICAL ALERT: Emergency hardware isolation enforced!")
        Log.e("JarvisFA_Guard", "ATTACK DETECTED! Bypassing local chassis into emergency lockdown.")
    }
}
