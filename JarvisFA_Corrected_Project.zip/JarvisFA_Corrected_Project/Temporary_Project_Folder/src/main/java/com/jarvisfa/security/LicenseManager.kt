package com.jarvisfa.security

object LicenseManager {
    init {
        System.loadLibrary("native-lib")
        AuditLogger.logEvent("LicenseManager: Native crypto libraries loaded successfully.")
    }

    fun activateProduct(licenseKey: String): Boolean {
        val deviceCode = HardwareFingerprint.generateDeviceCode()
        AuditLogger.logEvent("LicenseManager: Initiating JNI license verification seq...")
        
        // فراخوانی متد بومی لایه C++ برای تایید نهایی لایسنس
        val result = NativeBridge.verifyDeviceLicense(deviceCode, licenseKey)
        
        if (result) {
            AuditLogger.logEvent("LicenseManager: SUCCESS! Crypto signature verified offline.")
        } else {
            AuditLogger.logEvent("LicenseManager: CRITICAL! Hardware signature validation rejected.")
        }
        
        return result
    }
}
