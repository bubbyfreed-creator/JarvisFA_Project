package com.jarvisfa.security

import android.os.Build
import java.security.MessageDigest

object HardwareFingerprint {
    fun generateDeviceCode(): String {
        val rawShortId = "35" + 
                Build.BOARD.length % 10 + Build.BRAND.length % 10 + 
                Build.CPU_ABI.length % 10 + Build.DEVICE.length % 10 + 
                Build.DISPLAY.length % 10 + Build.HOST.length % 10 + 
                Build.ID.length % 10 + Build.MANUFACTURER.length % 10 + 
                Build.MODEL.length % 10 + Build.PRODUCT.length % 10 + 
                Build.TAGS.length % 10 + Build.TYPE.length % 10 + Build.USER.length % 10

        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(rawShortId.toByteArray(Charsets.UTF_8))
        
        // تبدیل به رشته ۳۲ کاراکتری هگزادسیمال برای سازگاری با برنامه مادر
        return hashBytes.joinToString("") { "%02x".format(it) }.take(32).uppercase()
    }
}
