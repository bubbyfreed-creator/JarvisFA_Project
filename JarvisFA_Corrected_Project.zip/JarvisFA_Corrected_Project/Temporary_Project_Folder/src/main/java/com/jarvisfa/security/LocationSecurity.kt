package com.jarvisfa.security

import android.location.Location
import android.util.Log

object LocationSecurity {

    // ۱. بررسی آفلاین و سخت‌افزاری برای تشخیص فیک بودن موقعیت مکانی (GPS Anti-Mock)
    fun isLocationFake(location: Location): Boolean {
        return try {
            // در اندرویدهای جدید این متد به صورت بومی فیک بودن لوکیشن را اسکن می‌کند
            val isMock = location.isFromMockProvider
            if (isMock) {
                AuditLogger.logEvent("🚨 SECURITY ALERT: Fake Mock Location detected on hardware level!")
            } else {
                AuditLogger.logEvent("💎 GPS Fabric Verified: Coordinates are authentic and clean.")
            }
            isMock
        } catch (e: Exception) {
            Log.e("JarvisFA_Location", "Failed to inspect GPS telemetry: ${e.message}")
            false
        }
    }
}
