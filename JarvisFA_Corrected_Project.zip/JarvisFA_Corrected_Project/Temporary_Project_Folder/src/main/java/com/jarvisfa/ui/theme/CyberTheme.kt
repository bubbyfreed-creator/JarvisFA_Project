package com.jarvisfa.ui.theme

import androidx.compose.ui.graphics.Color

object CyberTheme {
    val BackgroundDark = Color(0xFF0A0E17)
    val NeonCyan = Color(0xFF00F0FF)
    val NeonPurple = Color(0xFF9D000F)
    val GlassWhite = Color(0xFFFFFFFF).copy(alpha = 0.1f)
    val TextWhite = Color(0xFFE2E8F0)
}