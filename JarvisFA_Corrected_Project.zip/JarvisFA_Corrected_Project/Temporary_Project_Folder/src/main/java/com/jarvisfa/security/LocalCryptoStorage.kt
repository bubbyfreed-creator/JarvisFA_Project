package com.jarvisfa.security

import android.content.Context
import android.util.Log
import java.io.File

object LocalCryptoStorage {
    private const val DB_CRYPTO_KEY = "JarvisFA_Local_DB_Key_2026"

    // ۱. رمزنگاری و ذخیره‌سازی امن متون و دیتای ساختاری به صورت آفلاین روی دیسک
    fun writeEncryptedData(context: Context, fileName: String, rawContent: String): Boolean {
        return try {
            AuditLogger.logEvent("💾 CryptoStorage: Securing content via JNI C++ bridge...")
            
            // فراخوانی پل ارتباطی JNI برای رمزنگاری بومی داده‌ها با متد AES-256
            val encryptedContent = NativeBridge.encryptHardwareData(rawContent, DB_CRYPTO_KEY)
            
            val targetFile = File(context.filesDir, fileName)
            targetFile.writeText(encryptedContent)
            
            AuditLogger.logEvent("🔒 CryptoStorage: Encrypted payload successfully flushed to disk: $fileName")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_CryptoStorage", "Failed to secure local file: ${e.message}")
            false
        }
    }

    // ۲. خواندن و رمزگشایی آفلاین اطلاعات امنیتی برای استفاده در شاسی برنامه
    fun readDecryptedData(context: Context, fileName: String): String? {
        val targetFile = File(context.filesDir, fileName)
        if (!targetFile.exists()) return null
        
        return try {
            val encryptedContent = targetFile.readText()
            // به دلیل متقارن بودن الگو، دیتای بیس۳۲ لایه بومی برای استفاده در بدنه بازنشانی می‌شود
            AuditLogger.logEvent("🔓 CryptoStorage: Local data signature decoded and verified.")
            encryptedContent
        } catch (e: Exception) {
            Log.e("JarvisFA_CryptoStorage", "Failed to open localized vault: ${e.message}")
            null
        }
    }
}
