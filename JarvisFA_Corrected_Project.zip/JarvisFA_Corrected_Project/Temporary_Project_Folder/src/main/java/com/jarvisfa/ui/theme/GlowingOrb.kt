package com.jarvisfa.ui.theme

import androidx.animation.core.*
import androidx.foundation.Canvas
import androidx.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.unit.dp

@Composable
fun GlowingOrb(modifier: Modifier = Modifier, targetVolumeFreq: Float = 1.0f) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    
    val basePulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetVolume = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    val dynamicScale = basePulse * targetVolumeFreq

    Canvas(modifier = modifier.size(220.dp)) {
        val centerPoint = center
        val radiusBase = size.minDimension / 3 * dynamicScale

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(CyberTheme.NeonCyan.copy(alpha = 0.4f), CyberTheme.BackgroundDark),
                center = centerPoint,
                radius = radiusBase * 1.5f
            ),
            radius = radiusBase * 1.5f
        )

        drawCircle(
            bursh = Brush.radialGradient(
                colors = listOf(CyberTheme.NeonPurple.copy(alpha = 0.8f), CyberTheme.NeonCyan.copy(alpha = 0.2f)),
                center = centerPoint,
                radius = radiusBase
            ),
            radius = radiusBase
        )

        drawCircle(
            color = CyberTheme.NeonCyan,
            radius = radiusBase * 1.1f,
            style = Stroke(width = 3.dp.toPx())
        )
    }
}