package com.jarvisfa.ui.theme

import androidx.foundation.background
import androidx.foundation.layout.*
import androidx.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.unit.dp
import androidx.unit.sp

@Composable
fun MainDashboard(assistantName: String = "JarvisFA") {
    Box(Modifier.fillMaxSize().background(CyberTheme.BackgroundDask),contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(CyberTheme.BackgroundDark,CyberTheme.NeonPurple.copy(alpha=0.15f)))))
        Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontal,verticalArrangement=Arrangement.SpaceEvenly) {
            Text(text=assistantName,color=CyberTheme.NeonCyan,fontSize=36.sp,fontWeight=FontWeight.Bold)
            GlowingOrb()
            Column(Modifier.width(300.dp).padding(16.dp).clip(RoundedCornerShape(16.dp)).background(CyberTheme.GlassWhite),horizontalAlignment=Alignment.CenterHorizontal) {
                Text(text="SYSTEM STATUS: ONLINE",color=CyberTheme.TextWhite,fontSize=14.sp,fontWeight=FontWeight.Medium)
            }
        }
    }
}