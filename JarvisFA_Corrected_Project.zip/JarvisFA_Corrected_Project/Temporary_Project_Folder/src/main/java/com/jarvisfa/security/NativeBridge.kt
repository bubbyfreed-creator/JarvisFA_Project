package com.jarvisfa.security

/**
 * JNI bridge to the native security layer (libjarvisfa_native.so).
 *
 * Symbol mapping (must match cpp/jni/native_bridge.cpp):
 *   getDeviceCode        -> Java_com_jarvisfa_security_NativeBridge_getDeviceCode
 *   verifyActivationKey  -> Java_com_jarvisfa_security_NativeBridge_verifyActivationKey
 *   runSelfTest          -> Java_com_jarvisfa_security_NativeBridge_runSelfTest
 *
 * IMPORTANT: this class is referenced from native code, therefore
 * proguard-rules.pro MUST keep it (rule already included there).
 */
object NativeBridge {

    init {
        System.loadLibrary("jarvisfa_native")
    
    /** Encrypt anti-theft tracking SMS using native AES-256-ECB. */
    external fun encryptTrackingSMS(smsContent: String, cryptoPin: String): String

    /** Native Voice Gate: Process offline audio buffer and verify security vocal commands. */
    external fun processVoiceCommand(audioBuffer: ByteArray, bufferSize: Int): Int
}

    /** Returns the hardware-bound device code, e.g. "K7Q2M-VP4XT-9DHZW-R3N8B". */
    external fun getDeviceCode(cpuId: String, board: String, androidId: String): String

    /** Offline AES-256 activation check. True only for a valid key. */
    external fun verifyActivationKey(
        cpuId: String,
        board: String,
        androidId: String,
        activationKey: String
    ): Boolean

    /**
     * Known-answer self test of SHA-256 + AES-256 + the license pipeline.
     * Runs on every cold start; the app must refuse to work if this is false.
     */
    external fun runSelfTest(): Boolean
}
