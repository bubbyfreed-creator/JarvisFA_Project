package com.jarvisfa.security

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log

class AntiTheftGuard(private val context: Context) : LocationListener {
    private var isGhostModeActive = false
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val trustedNumber = "+989123456789"
    private val cryptoPin = "JarvisFA_SMS_Pin_2026" // پین اختصاصی برای رمزنگاری پیامک

    init {
        startSilentGhostMode()
        verifySimCardChassis()
    }

    fun startSilentGhostMode() {
        isGhostModeActive = true
        AuditLogger.logEvent("AntiTheft System: Silent Ghost Mode initialized.")
        requestLocationUpdates()
    }

    fun verifySimCardChassis(): Boolean {
        return try {
            val simOperator = telephonyManager.simOperator
            if (simOperator.isNotEmpty()) {
                AuditLogger.logEvent("SIM Matrix Verified. Operator Code: $simOperator")
                true
            } else {
                AuditLogger.logEvent("SECURITY ALERT: SIM hardware removed or offline!")
                false
            }
        } catch (e: Exception) {
            Log.e("JarvisFA_AntiTheft", "Failed to inspect SIM hardware: ${e.message}")
            true
        }
    }

    private fun requestLocationUpdates() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                60000L,
                10f,
                this
            )
            AuditLogger.logEvent("GPS tracking sensors linked successfully.")
        } catch (e: SecurityException) {
            Log.e("JarvisFA_AntiTheft", "Location permissions required for tracking: ${e.message}")
        }
    }

    override fun onLocationChanged(location: Location) {
        val lat = location.latitude
        val lng = location.longitude
        AuditLogger.logEvent("GPS Sync: Lat: $lat, Lng: $lng")
        sendSecureLocationSMS(lat, lng)
    }

    // ارتقای بخش ارسال اس‌ام‌اس با رمزنگاری بومی AES-256 و قفل JNI
    private fun sendSecureLocationSMS(latitude: Double, longitude: Double) {
        try {
            val smsManager = SmsManager.getDefault()
            val rawMessage = "JarvisFA Alert: Device coordinates updated. Google Maps: https://google.com"
            
            // فراخوانی پل ارتباطی JNI برای رمزنگاری بومی پیامک ردیاب
            val encryptedMessage = NativeBridge.encryptTrackingSMS(rawMessage, cryptoPin)
            
            smsManager.sendTextMessage(trustedNumber, null, encryptedMessage, null, null)
            AuditLogger.logEvent("Tracking SMS encrypted via C++ and dispatched securely.")
        } catch (e: Exception) {
            Log.w("JarvisFA_AntiTheft", "SMS hardware channel busy: ${e.message}")
        }
    }

    override fun onStatusChanged(provider: String?, status: Int, androidBundle: android.os.Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
