package com.jarvisfa.ui

object AppIconConfigs {
    // ۱. مشخصات آیکون برنامه فرزند: تم سبز و آبی سایبربانکی (بادیگارد و اتوماسیون)
    const val CHILD_APP_ICON_THEME = "🚨_CYBER_SHIELD_BOT"
    const val CHILD_ICON_DESCRIPTION = "آیکون نئونی مجهز به ردیاب سخت‌افزاری و سپر ضدسرقت"

    // ۲. مشخصات آیکون برنامه مادر: تم سرخ نئونی سلطنتی (اتاق فرمان و لایسنس‌ساز)
    const val MASTER_APP_ICON_THEME = "👑_MASTER_CORE_VALUT"
    const val MASTER_ICON_DESCRIPTION = "آیکون سلطنتی سرخ نئونی ویژه تولید لایسنس و کنترل تلمتری"
}
