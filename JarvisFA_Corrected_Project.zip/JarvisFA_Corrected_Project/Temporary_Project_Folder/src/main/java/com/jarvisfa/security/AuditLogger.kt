package com.jarvisfa.security

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AuditLogger {
    private val logList = mutableListOf<String>()
    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    // ۱. ثبت یک رویداد امنیتی جدید در حافظه موقت شاسی
    fun logEvent(event: String) {
        val timeStamp = dateFormat.format(Date())
        val formattedLog = "[$timeStamp] $event"
        
        synchronized(logList) {
            logList.add(0, formattedLog) // افزودن به ابتدای لیست برای نمایش جدیدترین‌ها
            if (logList.size > 50) logList.removeAt(logList.size - 1) // محدود کردن حجم حافظه
        }
        Log.i("JarvisFA_Logger", formattedLog)
    }

    // ۲. دریافت لیست کامل لاگ‌ها برای تزریق به رابط کاربری نئونی
    fun getLiveLogs(): List<String> {
        return synchronized(logList) { logList.toList() }
    }

    // ۳. پاکسازی بافر لاگ‌ها در صورت فعال شدن حالت شبح
    fun clearLogBuffer() {
        synchronized(logList) {
            logList.clear()
            Log.d("JarvisFA_Logger", "Audit buffer cleared securely.")
        }
    }
}
