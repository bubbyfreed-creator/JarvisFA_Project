package com.jarvisfa

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.jarvisfa.security.DeviceBinding
import com.jarvisfa.ui.MainDashboard
import com.jarvisfa.ui.CyberTheme
import com.jarvisfa.security.AuditLogger
import com.jarvisfa.security.HardwareSensorGuard

class MainActivity : ComponentActivity() {
    // تعریف متغیر نگهدارنده سنسورهای فیزیکی ضدسرقت شاسی
    private lateinit var sensorGuard: HardwareSensorGuard

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // ۱. فعال‌سازی لایه بومی محافظ ضد اسکرین‌شات و ضبط صفحه
        try {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
            AuditLogger.logEvent("AntiCapture: FLAG_SECURE enforced window wide. 🔒")
        } catch (e: Exception) {
            android.util.Log.e("JarvisFA_Main", "Failed to enforce screen capture shield: ${e.message}")
        }
        
        // ۲. راه‌اندازی و متصل کردن سیستم مانیتورینگ سنسورهای سخت‌افزاری (شتاب‌سنج و مجاورت)
        try {
            sensorGuard = HardwareSensorGuard(this)
            AuditLogger.logEvent("SensorCore: Accelerometer and Proximity triggers linked to main chassis! 🏃‍♂️⚡")
        } catch (e: Exception) {
            android.util.Log.e("JarvisFA_Main", "Failed to bind hardware sensors: ${e.message}")
        }
        
        val deviceBinding = DeviceBinding(this)
        val isVerified = deviceBinding.checkVerificationStatus()

        setContent {
            CyberTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (isVerified) {
                        MainDashboard()
                    } else {
                        com.jarvisfa.ui.SecureLockScreen()
                    }
                }
            }
        }
    }
}
