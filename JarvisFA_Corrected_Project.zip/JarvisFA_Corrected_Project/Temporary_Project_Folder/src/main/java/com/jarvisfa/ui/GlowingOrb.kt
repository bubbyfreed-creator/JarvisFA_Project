package com.jarvisfa.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun GlowingOrb(isListening: Boolean) {
    // ۱. ساخت انیمیشن پالس متحرک و نئونی برای زمان شنود صوتی فعال
    val infiniteTransition = rememberInfiniteTransition(label = "NeonPulse")
    
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.3f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ScaleAnimation"
    )

    val neonGlowColor = if (isListening) Color(0xFFFF0055) else Color(0xFF00FFCC)

    // ۲. پیاده‌سازی گوی متحرک سایبربانکی با گرادینت اختصاصی پروژه JarvisFA
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(160.dp)
            .scale(pulseScale)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(neonGlowColor.copy(alpha = 0.4f), Color.Transparent)
                ),
                shape = CircleShape
            )
    ) {
        // هسته مرکزی شاسی صوتی
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF121829), Color(0xFF0A0F1D))
                    ),
                    shape = CircleShape
                )
                .border(2.dp, neonGlowColor, CircleShape)
        )
    }
}
