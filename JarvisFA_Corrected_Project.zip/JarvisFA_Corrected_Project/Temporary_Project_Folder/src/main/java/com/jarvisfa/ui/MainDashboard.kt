package com.jarvisfa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvisfa.VoiceProfile
import com.jarvisfa.security.AuditLogger
import com.jarvisfa.security.NativeBridge

@Composable
fun MainDashboard() {
    var isListening by remember { mutableStateOf(false) }
    val voiceMenu = VoiceProfile.getVoiceMenu()
    var selectedVoice by remember { mutableStateOf("Jarvis_Classic_Male") }

    val isDebuggerConnected = remember { NativeBridge.isDebuggerAttached() }
    
    // وضعیت زنده لایه ماندگاری و ضد ریست فکتوری در پارتیشن سیستم
    var isAntiResetSecure by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0A0F1D)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("👑 JARVIS-FA MULTI-SHIELD 👑", color = Color(0xFF00FFCC), fontSize = 20.sp, modifier = Modifier.padding(top = 10.dp))
            Text("✨ هوش صوتی و امنیتی زنده کارفرما فعال است ✨", color = Color(0xFF9900FF), fontSize = 11.sp)
        }

        // مانیتورینگ جامع وضعیت با افزودن شاخص زنده ضد ریست فکتوری و بقای رام
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
            Text(
                text = if (isAntiResetSecure) "🔒 ضد ریست‌فکتوری: ماندگاری در پارتیشن سیستم فعال 💥" else "⚠️ سیستم ضد فرمت غیرفعال است",
                color = if (isAntiResetSecure) Color(0xFF00FFCC) else Color(0xFFFFCC00),
                fontSize = 11.sp
            )
            Text("💻 امنیت ترمینال: فرامين شل ایمن و فایروال روت فعال 🔒", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🔌 ضد اورشارژ: مدار محافظ ۱۰۰٪ فعال و ایمن 🔋", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🛠️ سلامت رام: سیستم‌عامل ۱۰۰٪ ترمیم‌شده و پایدار 📱", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🚨 آنتی‌دیباگ: محیط کاملاً ایزوله و ضد کرک 🕵️‍♂️", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🔒 گاوصندوق داده: کلیدها پایدار و دیسک رمزنگاری (AES-256) 💎", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🛰️ ردیاب جی‌پاس: فعال و ضد لوکیشن فیک 💎", color = Color(0xFF00FFCC), fontSize = 11.sp)
            Text("🤖 اتوماسیون ربات‌ها: فعال و آماده استخراج 🟢", color = Color(0xFF00FFCC), fontSize = 11.sp)
        }

        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Button(onClick = { 
                isListening = !isListening
                AuditLogger.logEvent("🎙️ استریم زنده شنود صوتی فعال شد.")
            }) {
                Text(if (isListening) "🛑 توقف شنود" else "🎙️ شروع شنود آفلاین")
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text("🎤 پروفایل صوتی فعال: $selectedVoice", color = Color.White, fontSize = 13.sp)
        }
    }
}
