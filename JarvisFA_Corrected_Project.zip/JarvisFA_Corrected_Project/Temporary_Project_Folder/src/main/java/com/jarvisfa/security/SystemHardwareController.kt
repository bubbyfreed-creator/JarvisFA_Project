package com.jarvisfa.security

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import android.provider.Settings
import android.util.Log

class SystemHardwareController(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    fun processHardwareCommand(parsedText: String): Boolean {
        val command = parsedText.trim().lowercase()
        return when {
            command.contains("حالت پرواز فعال") -> toggleAirplaneMode(true)
            command.contains("حالت پرواز غیرفعال") -> toggleAirplaneMode(false)
            command.contains("گوشی سایلنت") -> toggleSilentMode(true)
            command.contains("صدا فعال") -> toggleSilentMode(false)
            command.contains("وای فای روشن") || command.contains("wifi on") -> toggleWifi(true)
            command.contains("وای فای خاموش") || command.contains("wifi off") -> toggleWifi(false)
            command.contains("اینترنت روشن") -> toggleMobileData(true)
            command.contains("اینترنت خاموش") -> toggleMobileData(false)
            command.contains("بلوتوث روشن") || command.contains("bluetooth on") -> toggleBluetooth(true)
            command.contains("بلوتوث خاموش") || command.contains("bluetooth off") -> toggleBluetooth(false)
            command.contains("صدا حداکثر") || command.contains("volume max") -> setHardwareVolume(100)
            command.contains("صدا متوسط") || command.contains("volume medium") -> setHardwareVolume(50)
            command.contains("صدا حداقل") || command.contains("volume low") -> setHardwareVolume(10)
            
            // ماژول جدید تغییر میزان نور صفحه نمایش سخت‌افزاری بر اساس فرامین صوتی بین‌المللی
            command.contains("نور صفحه حداکثر") || command.contains("brightness max") || command.contains("屏幕亮度最大") -> setHardwareBrightness(255)
            command.contains("نور صفحه متوسط") || command.contains("brightness medium") || command.contains("屏幕亮度 मध्यम") -> setHardwareBrightness(128)
            command.contains("نور صفحه حداقل") || command.contains("brightness low") || command.contains("屏幕亮度最小") -> setHardwareBrightness(20)
            
            else -> {
                Log.d("JarvisFA_Hardware", "Command mapping skipped for pattern: $command")
                false
            }
        }
    }

    private fun toggleAirplaneMode(enable: Boolean): Boolean {
        return try {
            AuditLogger.logEvent("Hardware: Requesting Airplane Mode -> $enable")
            val intent = Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED).apply { putExtra("state", enable) }
            context.sendBroadcast(intent)
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "System restriction met for airplane broadcast: ${e.message}")
            false
        }
    }

    private fun toggleSilentMode(enable: Boolean): Boolean {
        return try {
            if (enable) {
                audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
                AuditLogger.logEvent("Hardware: Audio chassis set to SILENT.")
            } else {
                audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
                AuditLogger.logEvent("Hardware: Audio chassis set to NORMAL.")
            }
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Failed to shift hardware ringer state: ${e.message}")
            false
        }
    }

    private fun setHardwareVolume(percentage: Int): Boolean {
        return try {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val targetVolume = (maxVolume * (percentage / 100.0f)).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, AudioManager.FLAG_SHOW_UI)
            AuditLogger.logEvent("Hardware: Audio stream speaker/music set to $percentage%")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Failed to adjust hardware volume stream: ${e.message}")
            false
        }
    }

    // لایه جدید کنترل سخت‌افزاری و سیستمی میزان روشنایی صفحه نمایش
    private fun setHardwareBrightness(brightnessValue: Int): Boolean {
        return try {
            // اعمال مقدار روشنایی از بازه 0 تا 255 در تنظیمات سیستمی اندروید
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightnessValue
            )
            val percent = ((brightnessValue / 255.0f) * 100).toInt()
            AuditLogger.logEvent("Hardware: Screen brightness adjusted to $percent%")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Write settings permission required for brightness: ${e.message}")
            false
        }
    }

    private fun toggleWifi(enable: Boolean): Boolean {
        return try {
            @Suppress("DEPRECATION")
            wifiManager.isWifiEnabled = enable
            AuditLogger.logEvent("Hardware: Wi-Fi state changed to -> $enable")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Failed to toggle Wi-Fi framework: ${e.message}")
            false
        }
    }

    private fun toggleMobileData(enable: Boolean): Boolean {
        return try {
            AuditLogger.logEvent("Hardware: Mobile Data framework toggled to -> $enable")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Failed to shift cellular data state: ${e.message}")
            false
        }
    }

    private fun toggleBluetooth(enable: Boolean): Boolean {
        if (bluetoothAdapter == null) return false
        return try {
            @Suppress("DEPRECATION")
            if (enable) bluetoothAdapter.enable() else bluetoothAdapter.disable()
            AuditLogger.logEvent("Hardware: Bluetooth state shifted -> $enable")
            true
        } catch (e: Exception) {
            Log.e("JarvisFA_Hardware", "Failed to toggle Bluetooth state: ${e.message}")
            false
        }
    }
}
