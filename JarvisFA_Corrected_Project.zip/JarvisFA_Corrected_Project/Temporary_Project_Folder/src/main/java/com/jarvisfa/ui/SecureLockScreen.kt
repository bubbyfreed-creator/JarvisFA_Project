package com.jarvisfa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvisfa.security.AuditLogger
import com.jarvisfa.security.SecurityGuard

@Composable
fun SecureLockScreen() {
    var passwordAttempts by remember { mutableStateOf(0) }
    var lockScreenStatus by remember { mutableStateOf("🔒 شاسی امنیتی قفل است. لطفا پین را وارد کنید.") }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0A0F1D)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🚨 JARVIS-FA SECURE LOCK 🚨", color = Color(0xFFFF0055), fontSize = 20.sp)
        Spacer(modifier = Modifier.height(20.dp))
        Text(lockScreenStatus, color = Color.White, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(30.dp))
        
        // دکمه شبیه‌سازی ورود پین اشتباه توسط هکر یا شخص ثالث
        Button(onClick = { 
            passwordAttempts++
            AuditLogger.logEvent("⚠️ LockScreen: Failed password attempt #$passwordAttempts recorded.")
            if (passwordAttempts >= 3) {
                lockScreenStatus = "🚨 سیستم قفل شدید شد! دسترسی مسدود است."
                AuditLogger.logEvent("🚨 CRITICAL: Brute-force threshold met! Triggering isolation.")
            } else {
                lockScreenStatus = "❌ پین نادرست است! تلاش مجدد ($passwordAttempts/3)"
            }
        }) {
            Text("⌨️ شبیه‌سازی ورود پین اشتباه")
        }
    }
}
