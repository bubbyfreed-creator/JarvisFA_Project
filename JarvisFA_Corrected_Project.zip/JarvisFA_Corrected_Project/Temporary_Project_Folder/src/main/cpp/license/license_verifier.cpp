#include "license_verifier.h"

#include <cstring>

#include "crypto/aes256.h"
#include "crypto/base32.h"
#include "crypto/sha256.h"

namespace jf {

namespace {

// ============================================================================
// MASTER KEY STORAGE (OBFUSCATED AT REST)
// ----------------------------------------------------------------------------
// ATTENTION (employer):
//   * The bytes below are XOR-obfuscated: obf[i] = key[i] ^ (uint8_t)(0xA5 + 31*i)
//   * The PLACEHOLDER master key currently compiled in is:
//       "JarvisFA-MasterKey-2026-SECURE!!" (32 ASCII bytes)
//   * BEFORE RELEASE:
//       1) Generate your own key:
//          python3 -c "import secrets; print(', '.join('0x%02x' % b for b in secrets.token_bytes(32)))"
//       2) Obfuscate it with the same formula and paste the result below.
//       3) Put the SAME plain key in tools/KeyGenerator.py.
//   * Anyone holding the plain key can forge activation keys for ANY device,
//     so KeyGenerator.py must never be published and stays on your machine.
// ============================================================================
const uint8_t kMasterKeyObf[32] = {
    0xef, 0xa5, 0x91, 0x74, 0x48, 0x33, 0x19, 0x3f,
    0xb0, 0xf1, 0xba, 0x89, 0x6d, 0x5d, 0x25, 0x3d,
    0xf0, 0xcd, 0xfe, 0xc0, 0x21, 0x02, 0x79, 0x43,
    0xde, 0xe9, 0x88, 0xbf, 0x5b, 0x6d, 0x66, 0x47
};

void getMasterKey(uint8_t out[32]) {
    for (int i = 0; i < 32; ++i) {
        out[i] = static_cast<uint8_t>(
            kMasterKeyObf[i] ^ static_cast<uint8_t>(0xA5u + 31u * static_cast<unsigned>(i)));
    }
}

const char* kLicensePrefix = "JarvisFA|License|v1|";
const size_t kKeyChars = 24;   // -> "XXXXXX-XXXXXX-XXXXXX-XXXXXX"
const size_t kKeyGroup = 6;

std::string normalizeCode(const std::string& code) {
    std::string norm;
    norm.reserve(code.size());
    for (const char ch : code) {
        const unsigned char c = static_cast<unsigned char>(ch);
        if ((c >= 'A' && c <= 'Z') || (c >= '2' && c <= '7')) {
            norm.push_back(static_cast<char>(c));
        } else if (c >= 'a' && c <= 'z') {
            norm.push_back(static_cast<char>(c - 'a' + 'A'));
        }
        // dashes, spaces, '=' and any other characters are ignored
    }
    return norm;
}

std::string expectedRawKey(const uint8_t licenseBlock[16]) {
    uint8_t masterKey[32];
    getMasterKey(masterKey);

    uint8_t cipher[16];
    aes256EncryptBlock(masterKey, licenseBlock, cipher);

    std::string raw = base32Encode(cipher, 16);
    const size_t eq = raw.find('=');
    const std::string stripped = (eq == std::string::npos) ? raw : raw.substr(0, eq);
    return stripped.substr(0, kKeyChars);
}

} // namespace

void licenseBlockFromDeviceCode(const std::string& deviceCodeGrouped,
                                uint8_t licenseBlockOut[16]) {
    const std::string raw = normalizeCode(deviceCodeGrouped).substr(0, 20);

    std::string seed;
    seed.reserve(48);
    seed.append(kLicensePrefix);
    seed.append(raw);

    uint8_t digest[32];
    sha256(reinterpret_cast<const uint8_t*>(seed.data()), seed.size(), digest);
    std::memcpy(licenseBlockOut, digest, 16);
}

std::string buildActivationKey(const uint8_t licenseBlock[16]) {
    return groupString(expectedRawKey(licenseBlock), kKeyGroup);
}

bool verifyActivationKey(const uint8_t licenseBlock[16], const std::string& candidate) {
    const std::string expected = expectedRawKey(licenseBlock);
    const std::string norm = normalizeCode(candidate);

    if (norm.size() != expected.size()) {
        return false;
    }
    unsigned diff = 0;
    for (size_t i = 0; i < expected.size(); ++i) {
        diff |= static_cast<unsigned>(norm[i]) ^ static_cast<unsigned>(expected[i]);
    }
    return diff == 0;
}

} // namespace jf
