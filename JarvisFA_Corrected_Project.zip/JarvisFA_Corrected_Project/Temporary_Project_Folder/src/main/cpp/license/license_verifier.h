#ifndef JARVISFA_LICENSE_LICENSE_VERIFIER_H
#define JARVISFA_LICENSE_LICENSE_VERIFIER_H

#include <cstdint>
#include <string>

namespace jf {

// Derives the 16-byte license block from the grouped device code
// (e.g. "K7Q2M-VP4XT-9DHZW-R3N8B"). Same computation runs inside
// KeyGenerator.py -> both sides agree without any network.
void licenseBlockFromDeviceCode(const std::string& deviceCodeGrouped,
                                uint8_t licenseBlockOut[16]);

// Returns the canonical activation key (grouped Base32, 24 chars).
std::string buildActivationKey(const uint8_t licenseBlock[16]);

// Offline verification, constant-time comparison.
bool verifyActivationKey(const uint8_t licenseBlock[16], const std::string& candidate);

} // namespace jf

#endif // JARVISFA_LICENSE_LICENSE_VERIFIER_H
