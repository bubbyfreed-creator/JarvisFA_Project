#ifndef JARVISFA_LICENSE_DEVICE_BINDING_H
#define JARVISFA_LICENSE_DEVICE_BINDING_H

#include <cstdint>
#include <string>

namespace jf {

// Builds the domain-separated seed from hardware parameters, hashes it with
// SHA-256, and returns the 16-byte device block (first half of the digest).
// Also returns the human-readable "device code" (grouped Base32 of the digest).
void computeDeviceSeedBlock(const std::string& cpuId,
                            const std::string& board,
                            const std::string& androidId,
                            uint8_t deviceBlockOut[16]);

// Returns the full device code string, e.g. "K7Q2M-VP4XT-9DHZW-R3N8B".
std::string getDeviceCode(const std::string& cpuId,
                          const std::string& board,
                          const std::string& androidId);

} // namespace jf

#endif // JARVISFA_LICENSE_DEVICE_BINDING_H
