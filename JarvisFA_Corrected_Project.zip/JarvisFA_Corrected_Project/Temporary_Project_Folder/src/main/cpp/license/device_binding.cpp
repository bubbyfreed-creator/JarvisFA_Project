#include "device_binding.h"

#include <cstring>

#include "crypto/base32.h"
#include "crypto/sha256.h"

namespace jf {

namespace {
// Domain separation prefix: prevents cross-protocol reuse of the hash.
const char* kSeedPrefix = "JarvisFA|DeviceBinding|v1|";
const size_t kDeviceCodeChars = 20;   // Base32 chars shown to the customer
const size_t kDeviceCodeGroup = 5;    // "XXXXX-XXXXX-XXXXX-XXXXX"
} // namespace

void computeDeviceSeedBlock(const std::string& cpuId,
                            const std::string& board,
                            const std::string& androidId,
                            uint8_t deviceBlockOut[16]) {
    std::string seed;
    seed.reserve(64 + cpuId.size() + board.size() + androidId.size());
    seed.append(kSeedPrefix);
    seed.append(cpuId);
    seed.push_back('|');
    seed.append(board);
    seed.push_back('|');
    seed.append(androidId);

    uint8_t digest[32];
    sha256(reinterpret_cast<const uint8_t*>(seed.data()), seed.size(), digest);
    std::memcpy(deviceBlockOut, digest, 16);
}

std::string getDeviceCode(const std::string& cpuId,
                          const std::string& board,
                          const std::string& androidId) {
    std::string seed;
    seed.reserve(64 + cpuId.size() + board.size() + androidId.size());
    seed.append(kSeedPrefix);
    seed.append(cpuId);
    seed.push_back('|');
    seed.append(board);
    seed.push_back('|');
    seed.append(androidId);

    uint8_t digest[32];
    sha256(reinterpret_cast<const uint8_t*>(seed.data()), seed.size(), digest);

    std::string raw = base32Encode(digest, 32);
    const std::string stripped = raw.substr(0, raw.find('='));
    return groupString(stripped.substr(0, kDeviceCodeChars), kDeviceCodeGroup);
}

} // namespace jf
