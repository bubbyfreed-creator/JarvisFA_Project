#ifndef SHA256_H
#define SHA256_H

#include <string>

// تعریف تابع بومی هش SHA-256 برای استفاده در اعتبارسنجی لایسنس سخت‌افزاری JarvisFA
std::string sha256(const std::string& str);

#endif // SHA256_H
