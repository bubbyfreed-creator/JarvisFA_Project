#include <jni.h>
#include <android/log.h>

#include <string>

#include "crypto/aes256.h"
#include "crypto/sha256.h"
#include "license/device_binding.h"
#include "license/license_verifier.h"

#define LOG_TAG "JarvisFA-Native"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

std::string toStdString(JNIEnv* env, jstring value) {
    if (value == nullptr) return std::string();
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string result = (chars != nullptr) ? std::string(chars) : std::string();
    if (chars != nullptr) env->ReleaseStringUTFChars(value, chars);
    return result;
}

bool verifyWithHardware(const std::string& cpuId,
                        const std::string& board,
                        const std::string& androidId,
                        const std::string& activationKey) {
    // 1) Hardware -> device code (displayed to the customer).
    const std::string deviceCode = jf::getDeviceCode(cpuId, board, androidId);
    // 2) Device code -> license block (same step as KeyGenerator.py).
    uint8_t licenseBlock[16];
    jf::licenseBlockFromDeviceCode(deviceCode, licenseBlock);
    // 3) Constant-time key verification.
    return jf::verifyActivationKey(licenseBlock, activationKey);
}

} // namespace

extern "C" {

// Returns the hardware-bound device code shown to the customer, e.g.
// "K7Q2M-VP4XT-9DHZW-R3N8B".
JNIEXPORT jstring JNICALL
Java_com_jarvisfa_security_NativeBridge_getDeviceCode(JNIEnv* env,
                                                      jclass /* clazz */,
                                                      jstring cpuId,
                                                      jstring board,
                                                      jstring androidId) {
    if (cpuId == nullptr || board == nullptr || androidId == nullptr) {
        LOGE("getDeviceCode: null argument");
        return nullptr;
    }
    const std::string code = jf::getDeviceCode(toStdString(env, cpuId),
                                               toStdString(env, board),
                                               toStdString(env, androidId));
    return env->NewStringUTF(code.c_str());
}

// Offline AES-256 activation check. Returns JNI_TRUE only for a valid key.
JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_verifyActivationKey(JNIEnv* env,
                                                            jclass /* clazz */,
                                                            jstring cpuId,
                                                            jstring board,
                                                            jstring androidId,
                                                            jstring activationKey) {
    if (cpuId == nullptr || board == nullptr || androidId == nullptr ||
        activationKey == nullptr) {
        LOGE("verifyActivationKey: null argument");
        return JNI_FALSE;
    }
    const bool ok = verifyWithHardware(toStdString(env, cpuId),
                                       toStdString(env, board),
                                       toStdString(env, androidId),
                                       toStdString(env, activationKey));
    return ok ? JNI_TRUE : JNI_FALSE;
}

// Runs on every cold start from Kotlin; blocks the app if crypto is broken.
JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_runSelfTest(JNIEnv* /* env */, jclass /* clazz */) {
    // 1) SHA-256("abc") known answer (FIPS 180-4).
    const char* msg = "abc";
    uint8_t digest[32];
    jf::sha256(reinterpret_cast<const uint8_t*>(msg), 3, digest);
    static const uint8_t kShaExpect[32] = {
        0xba,0x78,0x16,0xbf,0x8f,0x01,0xcf,0xea,0x41,0x41,0x40,0xde,0x5d,0xae,0x22,
        0x23,0xb0,0x03,0x61,0xa3,0x96,0x17,0x7a,0x9c,0xb4,0x10,0xff,0x61,0xf2,0x00,
        0x15,0xad
    };
    if (memcmp(digest, kShaExpect, 32) != 0) {
        LOGE("self-test failed: SHA-256 KAT");
        return JNI_FALSE;
    }

    // 2) FIPS-197 AES-256 known answer test.
    static const uint8_t kAesKey[32] = {
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
        0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
        0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f
    };
    static const uint8_t kAesPt[16] = {
        0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,
        0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff
    };
    static const uint8_t kAesCtExpect[16] = {
        0x8e,0xa2,0xb7,0xca,0x51,0x67,0x45,0xbf,
        0xea,0xfc,0x49,0x90,0x4b,0x49,0x60,0x89
    };
    uint8_t cipher[16];
    uint8_t plain[16];
    jf::aes256EncryptBlock(kAesKey, kAesPt, cipher);
    if (memcmp(cipher, kAesCtExpect, 16) != 0) {
        LOGE("self-test failed: AES-256 encrypt KAT");
        return JNI_FALSE;
    }
    jf::aes256DecryptBlock(kAesKey, cipher, plain);
    if (memcmp(plain, kAesPt, 16) != 0) {
        LOGE("self-test failed: AES-256 decrypt KAT");
        return JNI_FALSE;
    }

    // 3) License round-trip: device code -> block -> key -> verify.
    const std::string deviceCode =
        jf::getDeviceCode("cpu-test", "board-test", "android-test");
    uint8_t block[16];
    jf::licenseBlockFromDeviceCode(deviceCode, block);
    const std::string goodKey = jf::buildActivationKey(block);
    if (!jf::verifyActivationKey(block, goodKey)) {
        LOGE("self-test failed: license positive");
        return JNI_FALSE;
    }
    if (jf::verifyActivationKey(block, "AAAAAA-BBBBBB-CCCCCC-DDDDDD")) {
        LOGE("self-test failed: license negative");
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

} // extern "C"
