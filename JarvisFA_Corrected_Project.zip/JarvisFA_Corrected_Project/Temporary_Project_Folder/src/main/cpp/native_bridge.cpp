#include <jni.h>
#include <string>
#include "sha256.h"

// الگو یا نمک امنیتی مشترک بین برنامه مادر و فرزند برای اعتبارسنجی
const std::string SECRET_SALT = "JarvisFA_Crypto_Salt_2026";

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_verifyDeviceLicense(JNIEnv* env, jobject thiz, jstring device_id, jstring license_key) {
    const char* native_device_id = env->GetStringUTFChars(device_id, nullptr);
    const char* native_license_key = env->GetStringUTFChars(license_key, nullptr);

    // ۱. شبیه‌سازی دقیق منطق هش برنامه مادر پایتون
    std::string raw_payload = std::string(native_device_id) + SECRET_SALT;
    std::string secure_hex = sha256(raw_payload);
    
    // ۲. قالب‌بندی هش تولید شده به بلوک‌های ۴ کاراکتری
    std::string expected_key = "";
    for (int i = 0; i < 24; i += 4) {
        expected_key += secure_hex.substr(i, 4);
        if (i < 20) expected_key += "-";
    }

    // ۳. مطابقت دادن کلید ورودی کاربر با کلید محاسباتی بومی دستگاه
    bool is_valid = (std::string(native_license_key) == expected_key);
    
    env->ReleaseStringUTFChars(device_id, native_device_id);
    env->ReleaseStringUTFChars(license_key, native_license_key);
    
    return is_valid ? JNI_TRUE : JNI_FALSE;
}
