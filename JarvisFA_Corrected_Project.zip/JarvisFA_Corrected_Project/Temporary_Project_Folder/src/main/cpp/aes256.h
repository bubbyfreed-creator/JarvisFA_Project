#ifndef AES256_H
#define AES256_H

#include <string>

// تعریف توابع بومی رمزنگاری و رمزگشایی برای استفاده در سراسر لایه JNI پروژه JarvisFA
std::string aes256_encrypt(const std::string& plain_text, const std::string& key);
std::string aes256_decrypt(const std::string& cipher_text, const std::string& key);

#endif // AES256_H
