#ifndef BASE32_H
#define BASE32_H

#include <string>

// تعریف تابع بومی انکودر Base32 برای فشرده‌سازی کدهای سخت‌افزاری در پروژه JarvisFA
std::string base32_encode(const std::string& data);

#endif // BASE32_H
