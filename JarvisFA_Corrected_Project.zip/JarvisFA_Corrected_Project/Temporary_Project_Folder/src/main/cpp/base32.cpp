#include <string>
#include <vector>

// جدول الفبای بومی و آفلاین Base32 برای پروژه JarvisFA
const char BASE32_ALPHABET[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

std::string base32_encode(const std::string& data) {
    if (data.empty()) return "";
    
    std::string result;
    int buffer = 0;
    int bits_left = 0;
    
    for (unsigned char c : data) {
        buffer = (buffer << 8) | c;
        bits_left += 8;
        while (bits_left >= 5) {
            bits_left -= 5;
            result.push_back(BASE32_ALPHABET[(buffer >> bits_left) & 0x1F]);
        }
    }
    
    if (bits_left > 0) {
        buffer <<= (5 - bits_left);
        result.push_back(BASE32_ALPHABET[buffer & 0x1F]);
    }
    
    return result;
}
