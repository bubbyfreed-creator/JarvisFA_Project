#include "base32.h"

namespace jf {

namespace {
const char kAlphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
} // namespace

std::string base32Encode(const uint8_t* data, size_t len) {
    std::string out;
    size_t i = 0;
    while (i + 5 <= len) {
        uint64_t buf = 0;
        for (int j = 0; j < 5; ++j) buf = (buf << 8) | data[i + static_cast<size_t>(j)];
        for (int j = 0; j < 8; ++j) {
            out.push_back(kAlphabet[(buf >> (35 - 5 * j)) & 31u]);
        }
        i += 5;
    }
    const size_t rem = len - i;
    if (rem > 0) {
        uint64_t buf = 0;
        for (size_t j = 0; j < rem; ++j) {
            buf |= static_cast<uint64_t>(data[i + j]) << (8 * (4 - j));
        }
        const int outChars = static_cast<int>((rem * 8 + 4) / 5);
        for (int j = 0; j < outChars; ++j) {
            out.push_back(kAlphabet[(buf >> (35 - 5 * j)) & 31u]);
        }
        while (out.size() % 8 != 0) out.push_back('=');
    }
    return out;
}

bool base32Decode(const std::string& encoded, std::vector<uint8_t>& out) {
    out.clear();
    int buffer = 0;
    int bitsLeft = 0;
    bool any = false;
    for (const char ch : encoded) {
        const unsigned char c = static_cast<unsigned char>(ch);
        if (c == '=') break;
        if (c == '-' || c == ' ' || c == '\t' || c == '\n' || c == '\r') continue;
        int v;
        if (c >= 'A' && c <= 'Z')      v = static_cast<int>(c - 'A');
        else if (c >= 'a' && c <= 'z') v = static_cast<int>(c - 'a');
        else if (c >= '2' && c <= '7') v = static_cast<int>(c - '2') + 26;
        else return false;
        any = true;
        buffer = (buffer << 5) | v;
        bitsLeft += 5;
        if (bitsLeft >= 8) {
            out.push_back(static_cast<uint8_t>((buffer >> (bitsLeft - 8)) & 0xFF));
            bitsLeft -= 8;
        }
    }
    return any;
}

std::string groupString(const std::string& s, size_t group) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (i != 0 && i % group == 0) out.push_back('-');
        out.push_back(s[i]);
    }
    return out;
}

} // namespace jf
