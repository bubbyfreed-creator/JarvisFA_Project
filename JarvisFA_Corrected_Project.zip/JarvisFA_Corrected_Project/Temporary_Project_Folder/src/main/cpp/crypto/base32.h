#ifndef JARVISFA_CRYPTO_BASE32_H
#define JARVISFA_CRYPTO_BASE32_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace jf {

// RFC 4648 Base32 (uppercase, with '=' padding on encode).
std::string base32Encode(const uint8_t* data, size_t len);

// Tolerant decode: skips '-', whitespace and stops at '='.
// Returns false if an invalid character is found or nothing was decoded.
bool base32Decode(const std::string& encoded, std::vector<uint8_t>& out);

// Insert a separator after every `group` characters (e.g. "XXXXX-XXXXX").
std::string groupString(const std::string& s, size_t group);

} // namespace jf

#endif // JARVISFA_CRYPTO_BASE32_H
