#ifndef JARVISFA_CRYPTO_AES256_H
#define JARVISFA_CRYPTO_AES256_H

#include <cstdint>

namespace jf {

// AES-256 block cipher (FIPS-197), single 16-byte block, no mode/padding.
void aes256EncryptBlock(const uint8_t key[32], const uint8_t in[16], uint8_t out[16]);
void aes256DecryptBlock(const uint8_t key[32], const uint8_t in[16], uint8_t out[16]);

} // namespace jf

#endif // JARVISFA_CRYPTO_AES256_H
