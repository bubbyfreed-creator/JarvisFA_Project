#ifndef JARVISFA_CRYPTO_SHA256_H
#define JARVISFA_CRYPTO_SHA256_H

#include <cstddef>
#include <cstdint>

namespace jf {

// One-shot SHA-256 (FIPS 180-4). `out` must have room for 32 bytes.
void sha256(const uint8_t* data, size_t len, uint8_t out[32]);

} // namespace jf

#endif // JARVISFA_CRYPTO_SHA256_H
