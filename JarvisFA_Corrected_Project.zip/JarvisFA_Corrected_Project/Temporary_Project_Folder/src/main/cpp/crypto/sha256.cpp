#include "sha256.h"

#include <cstring>
#include <vector>

namespace jf {

namespace {

inline uint32_t rotr(uint32_t x, uint32_t n) {
    return (x >> n) | (x << (32u - n));
}

const uint32_t kK[64] = {
    0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u,
    0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
    0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
    0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
    0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu,
    0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
    0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u,
    0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
    0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
    0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
    0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u,
    0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
    0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u,
    0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
    0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
    0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
};

} // namespace

void sha256(const uint8_t* data, size_t len, uint8_t out[32]) {
    uint32_t h[8] = {
        0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
        0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u
    };

    const uint64_t bitLen = static_cast<uint64_t>(len) * 8u;

    // Padding: 0x80, zeros until length % 64 == 56, then 64-bit big-endian bit length.
    size_t paddedLen = len + 1;
    while ((paddedLen % 64u) != 56u) {
        ++paddedLen;
    }
    std::vector<uint8_t> buf(paddedLen + 8, 0);
    if (len > 0) {
        std::memcpy(buf.data(), data, len);
    }
    buf[len] = 0x80u;
    for (int i = 0; i < 8; ++i) {
        buf[paddedLen + static_cast<size_t>(i)] =
            static_cast<uint8_t>(bitLen >> (56 - 8 * i));
    }

    for (size_t off = 0; off < buf.size(); off += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i) {
            const size_t p = off + static_cast<size_t>(4 * i);
            w[i] = (static_cast<uint32_t>(buf[p])     << 24) |
                   (static_cast<uint32_t>(buf[p + 1]) << 16) |
                   (static_cast<uint32_t>(buf[p + 2]) <<  8) |
                   (static_cast<uint32_t>(buf[p + 3]));
        }
        for (int i = 16; i < 64; ++i) {
            const uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            const uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }

        uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
        uint32_t e = h[4], f = h[5], g = h[6], hh = h[7];

        for (int i = 0; i < 64; ++i) {
            const uint32_t s1    = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            const uint32_t ch    = (e & f) ^ ((~e) & g);
            const uint32_t temp1 = hh + s1 + ch + kK[i] + w[i];
            const uint32_t s0    = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            const uint32_t maj   = (a & b) ^ (a & c) ^ (b & c);
            const uint32_t temp2 = s0 + maj;
            hh = g; g = f; f = e; e = d + temp1;
            d = c; c = b; b = a; a = temp1 + temp2;
        }

        h[0] += a; h[1] += b; h[2] += c; h[3] += d;
        h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }

    for (int i = 0; i < 8; ++i) {
        out[static_cast<size_t>(4 * i)]     = static_cast<uint8_t>(h[i] >> 24);
        out[static_cast<size_t>(4 * i) + 1] = static_cast<uint8_t>(h[i] >> 16);
        out[static_cast<size_t>(4 * i) + 2] = static_cast<uint8_t>(h[i] >>  8);
        out[static_cast<size_t>(4 * i) + 3] = static_cast<uint8_t>(h[i]);
    }
}

} // namespace jf
