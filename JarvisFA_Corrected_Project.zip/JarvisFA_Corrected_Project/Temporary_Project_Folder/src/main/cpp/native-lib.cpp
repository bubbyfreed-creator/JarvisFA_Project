#include <jni.h>
#include <string>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ptrace.h>
#include <fstream>
#include "aes256.h"
#include "sha256.h"
#include "base32.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarvisfa_security_NativeBridge_encryptHardwareData(JNIEnv* env, jobject thiz, jstring raw_data, jstring crypto_key) {
    const char* native_data = env->GetStringUTFChars(raw_data, nullptr);
    const char* native_key = env->GetStringUTFChars(crypto_key, nullptr);
    std::string encrypted = aes256_encrypt(std::string(native_data), std::string(native_key));
    std::string base32_result = base32_encode(encrypted);
    env->ReleaseStringUTFChars(raw_data, native_data);
    env->ReleaseStringUTFChars(crypto_key, native_key);
    return env->NewStringUTF(base32_result.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarvisfa_security_NativeBridge_encryptTrackingSMS(JNIEnv* env, jobject thiz, jstring sms_content, jstring secret_pin) {
    const char* native_sms = env->GetStringUTFChars(sms_content, nullptr);
    const char* native_pin = env->GetStringUTFChars(secret_pin, nullptr);
    std::string encrypted_sms = aes256_encrypt(std::string(native_sms), std::string(native_pin));
    std::string b32_sms = base32_encode(encrypted_sms);
    env->ReleaseStringUTFChars(sms_content, native_sms);
    env->ReleaseStringUTFChars(secret_pin, native_pin);
    return env->NewStringUTF(b32_sms.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_isDeviceRooted(JNIEnv* env, jobject thiz) {
    const char* paths[] = {
        "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
        "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
        "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"
    };
    struct stat buffer;
    for (int i = 0; i < 9; i++) {
        if (stat(paths[i], &buffer) == 0) return JNI_TRUE;
    }
    return JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_isEmulator(JNIEnv* env, jobject thiz) {
    const char* emu_files[] = {
        "/dev/socket/qemud", "/dev/qemu_pipe",
        "/system/lib/libc_malloc_debug_qemu.so", "/sys/module/qemu_trace"
    };
    struct stat buffer;
    for (int i = 0; i < 4; i++) {
        if (stat(emu_files[i], &buffer) == 0) return JNI_TRUE;
    }
    std::ifstream cpuinfo("/proc/cpuinfo");
    std::string line;
    while (std::getline(cpuinfo, line)) {
        if (line.find("QEMU") != std::string::npos || line.find("Goldfish") != std::string::npos) return JNI_TRUE;
    }
    return JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_isDebuggerAttached(JNIEnv* env, jobject thiz) {
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) < 0) return JNI_TRUE;
    return JNI_FALSE;
}

// تابع بومی جدید برای حفاظت در برابر اسکن و تخلیه حافظه رم (Anti-Memory Dumping)
extern "C" JNIEXPORT jboolean JNICALL
Java_com_jarvisfa_security_NativeBridge_isMemoryDumpDetected(JNIEnv* env, jobject thiz) {
    std::ifstream maps("/proc/self/maps");
    std::string line;
    while (std::getline(maps, line)) {
        // ردیابی کتابخانه‌ها و پورت‌های متداول ابزارهای مانیتورینگ رم و هوک حافظه
        if (line.find("frida") != std::string::npos || line.find("xposed") != std::string::npos) {
            return JNI_TRUE; // ابزار تخلیه رم یا هوک حافظه شناسایی شد!
        }
    }
    return JNI_FALSE; // حافظه کاملاً پاک و امن است
}
