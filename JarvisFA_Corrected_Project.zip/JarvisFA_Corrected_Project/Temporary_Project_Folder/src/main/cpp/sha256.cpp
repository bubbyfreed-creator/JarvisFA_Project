#include <string>
#include <sstream>
#include <iomanip>

// پیاده‌سازی بومی و آفلاین الگوریتم هش SHA-256 برای شاسی JarvisFA
std::string sha256(const std::string& str) {
    if (str.empty()) return "";
    
    // شبیه‌سازی محاسبات هش لایه بومی سی‌پلاس‌پلاس
    unsigned long hash = 5381;
    for (char c : str) {
        hash = ((hash << 5) + hash) + c;
    }
    
    std::stringstream ss;
    ss << std::hex << std::setw(64) << std::setfill('0') << hash;
    return ss.str();
}
