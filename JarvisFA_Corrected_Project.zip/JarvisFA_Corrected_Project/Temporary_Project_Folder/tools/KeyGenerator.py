import hashlib
import time

BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

def base32_decode(data):
    clean_data = data.strip().upper().replace("-", "")
    binary_str = ""
    for char in clean_data:
        val = BASE32_ALPHABET.find(char)
        if val == -1: continue
        binary_str += format(val, '05b')
    bytes_list = []
    for i in range(0, len(binary_str) - len(binary_str) % 8, 8):
        bytes_list.append(int(binary_str[i:i+8], 2))
    return bytes(bytes_list)

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def aes256_decrypt_simulation(cipher_bytes, key):
    try:
        # هماهنگ‌سازی طول کلید با هش کردن آن به طول ۳۲ بایت
        import hashlib
        hashed_key = hashlib.sha256(key.encode('utf-8') if isinstance(key, str) else key).digest()
        
        # رمزگشایی مستقیم دیتای بلوکی بر اساس پروتکل بومی
        cipher = AES.new(hashed_key, AES.MODE_ECB)
        decrypted_pad = cipher.decrypt(cipher_bytes)
        
        # حذف پدینگ استاندارد PKCS7
        return unpad(decrypted_pad, AES.block_size).decode('utf-8')
    except Exception as e:
        return f"[-] Decryption Error: {str(e)}"

def generate_secure_activation_key(device_code, region_token):
    clean_code = device_code.strip().upper()
    if len(clean_code) < 32:
        raise ValueError("دستگاه نامعتبر است!")
    secret_salt = "JarvisFA_Crypto_Salt_2026_" + region_token.strip().upper()
    raw_payload = clean_code + secret_salt
    hash_object = hashlib.sha256(raw_payload.encode('utf-8'))
    secure_hex = hash_object.hexdigest().upper()
    blocks = [secure_hex[i:i+4] for i in range(0, 24, 4)]
    return "-".join(blocks)

def main():
    print("=========================================")
    print(" 👑 JarvisFA Master Golden Final v5.0 👑 ")
    print("=========================================")
    print("1. 🔑 Generate Region-Based Activation Key")
    print("2. 📡 Decrypt AntiTheft Tracking SMS")
    print("3. 📊 Audit & Export Secure System Logs")
    print("4. 📦 Pack & Sign Centralized License File")
    print("=========================================")
    
    choice = input("Select Operation (1-4): ").strip()
    
    if choice == "1":
        try:
            device_input = input("Enter Device Code: ")
            region_input = input("Enter Active Region (e.g., GULF, EU, ASIA): ")
            key = generate_secure_activation_key(device_input, region_input)
            with open("secure_audit_report.txt", "a", encoding="utf-8") as f:
                f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] 🔑 License key generated for {region_input}.\n")
            print(f"\n[+] SUCCESS: Key Generated! 🎉\n[+] Key: {key}")
        except Exception as e:
            print(f"\n[-] Error: {e}")
            
    elif choice == "2":
        try:
            encrypted_sms = input("Enter Encrypted SMS Content: ")
            crypto_pin = "JarvisFA_SMS_Pin_2026"
            decoded_bytes = base32_decode(encrypted_sms)
            raw_sms = aes256_decrypt_simulation(decoded_bytes, crypto_pin)
            print(f"\n[+] SUCCESS: SMS Decrypted! 🎉\n[+] Output: {raw_sms}")
        except Exception as e:
            print(f"\n[-] Decryption Failed: {e}")
            
    elif choice == "3":
        print("\n[+] Initiating JarvisFA Telemetry Analyzer & Logger...")
        log_input = input("Paste Live Log Line for Verification: ").strip()
        with open("secure_audit_report.txt", "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {log_input}\n")
        if "CRITICAL" in log_input or "ALERT" in log_input or "خطر" in log_input:
            print("\n[!] WARNING: Threat token identified! Report exported. 🚨")
        else:
            print("\n[+] System log signature verified. State stable. 💎")
            
    elif choice == "4":
        print("\n[+] Executing Centralized License Encoder & Packer...")
        license_input = input("Enter License Key to Pack: ").strip()
        # شبیه‌سازی انکود نهایی پکت با تولید یک هش تاییدیه امضا شده
        package_signature = hashlib.md5(license_input.encode('utf-8')).hexdigest().upper()
        
        with open("license_package.lic", "w", encoding="utf-8") as f:
            f.write(f"ENC_DATA:{license_input}\nSIGN:{package_signature}\nSTAMP:{time.time()}")
            
        print("\n[+] SUCCESS! Centralized license packaged and signed into 'license_package.lic' 🎉📦")
            
    print("=========================================")

if __name__ == "__main__":
    main()
